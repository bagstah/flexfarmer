#!/usr/bin/env bash

#######################
# MAIN script body
#######################
#{"acceptedPartials":20,"rejectedPartials":0,"stalePartials":0,"space":36019442848628,"plots":331,"poolDifficulty":1,"processedSignagePoints":55,"foundBlocks":0,"averageLookupDuration":0.489440722,"failoverMode":false}

#. /hive/miners/custom/$CUSTOM_MINER/h-manifest.conf
#local LOG_NAME="$CUSTOM_LOG_BASENAME.log"

function parse_yaml {
   local prefix=$2
   local s='[[:space:]]*' w='[a-zA-Z0-9_]*' fs=$(echo @|tr @ '\034')
   sed -ne "s|,$s\]$s\$|]|" \
        -e ":1;s|^\($s\)\($w\)$s:$s\[$s\(.*\)$s,$s\(.*\)$s\]|\1\2: [\3]\n\1  - \4|;t1" \
        -e "s|^\($s\)\($w\)$s:$s\[$s\(.*\)$s\]|\1\2:\n\1  - \3|;p" $1 | \
   sed -ne "s|,$s}$s\$|}|" \
        -e ":1;s|^\($s\)-$s{$s\(.*\)$s,$s\($w\)$s:$s\(.*\)$s}|\1- {\2}\n\1  \3: \4|;t1" \
        -e    "s|^\($s\)-$s{$s\(.*\)$s}|\1-\n\1  \2|;p" | \
   sed -ne "s|^\($s\):|\1|" \
        -e "s|^\($s\)-$s[\"']\(.*\)[\"']$s\$|\1$fs$fs\2|p" \
        -e "s|^\($s\)-$s\(.*\)$s\$|\1$fs$fs\2|p" \
        -e "s|^\($s\)\($w\)$s:$s[\"']\(.*\)[\"']$s\$|\1$fs\2$fs\3|p" \
        -e "s|^\($s\)\($w\)$s:$s\(.*\)$s\$|\1$fs\2$fs\3|p" | \
   awk -F$fs '{
      indent = length($1)/2;
      vname[indent] = $2;
      for (i in vname) {if (i > indent) {delete vname[i]; idx[i]=0}}
      if(length($2)== 0){  vname[indent]= ++idx[indent] };
      if (length($3) > 0) {
         vn=""; for (i=0; i<indent; i++) { vn=(vn)(vname[i])("_")}
         printf("%s%s%s=\"%s\"\n", "'$prefix'",vn, vname[indent], $3);
      }
   }'
}

stats_raw=`curl --connect-timeout 2 --max-time 10 --silent --noproxy '*' http://127.0.0.1:3754/stats`
if [[ $? -ne 0 || -z $stats_raw ]]; then
	echo -e "${YELLOW}Failed to read $miner from localhost:8550${NOCOLOR}"
else
	khs=`echo $stats_raw | jq -r '.plots'`
	ac=`echo $stats_raw | jq -r '.acceptedPartials'`
	rj=`echo $stats_raw | jq -r '.rejectedPartials'`
	st=`echo $stats_raw | jq -r '.stalePartials'`

temparray=()
fanarray=()
hsarray=()

for folders in `parse_yaml ~user/flexfarmer/config.yml | grep plot_directories_ | cut -f2 -d\"` ; do
	mymount=`findmnt -o source -n $folders`
	mytemp=`hddtemp -n $mymount | tr -dc '[:alnum:]'`
	temparray+=($mytemp)
	myfreespace=`df -h $mymount --output=pcent | tail -1 | cut -f1 -d\%`
	myrevspace=`echo 101 - $myfreespace | bc`
	plotnum=`ls $folders/*.plot | wc -l`
	hsarray+=($plotnum)
	fanarray+=($myrevspace)
done

	hs=`printf '%s\n' "${hsarray[@]}" | jq -R . | jq -s .`
	temp=`printf '%s\n' "${temparray[@]}" | jq -R . | jq -s .`
	fan=`printf '%s\n' "${fanarray[@]}" | jq -R . | jq -s .`

	stats=$(jq --arg hs_units "plots" --argjson temp "$temp" --argjson fan "$fan" --arg ac "$ac" --arg rj "$rj"  --argjson hs "$hs" --arg algo "customalgo"\
		'{$hs, hs_units: "hs", temp: $temp, fan: $fan, $algo, ar: [$ac, $rj]}' <<< "$stats_raw")
fi

	[[ -z $khs ]] && khs=0
	[[ -z $stats ]] && stats="null"

echo KHS $khs
echo STATS $stats

#echo ${temparray[@]}
#echo ${fanarray[@]}
#echo ${hsarray[@]}
